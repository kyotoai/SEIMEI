#!/bin/sh -xe

##make clean
make 2>&1 | tee CompileList.txt
